# Copilot / Coding Agent Instructions for Pure OS

Use these rules for every change in this repository.

## Naming and language

- The intelligence layer is always called **Pure Intelligence**.
- The command language is **PureLang**.
- Prefer geometry-native, geometry-coded, shape-validated, render-safe, Governor-approved, and PureLang-native wording.
- Do not rename Pure Intelligence.

## Project status honesty

- Treat this as a prototype and cloud-build candidate until CI produces an APK and Ryan confirms a phone test.
- Do not claim the OS is finished, installed, device-tested, or release-ready unless evidence files prove it.
- Separate concept/design files from runnable Android code.

## Build target

- Primary runnable target: `android/PureOSLaunchCandidate`.
- Primary CI workflow: `.github/workflows/pureos_android_debug_build.yml`.
- When fixing builds, make small commits, keep logs, and update the v17.41 handoff notes.

## Safety and approval

- Real-world deployment, risky automation, security-policy weakening, or external binary execution requires Ryan approval.
- Keep Governor and approval gates intact.
- Do not add secrets, tokens, passwords, private keys, or personal credentials.
