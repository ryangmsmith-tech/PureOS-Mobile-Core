# v17.41 Next Target — Cloud APK Artifact or Exact Build Error Fix

Run the phone-only GitHub Actions build. Then choose one path:

## Path A — APK artifact exists
- Download APK artifact.
- Install on S25 Ultra.
- Launch Pure OS.
- Tap Pure Intelligence diamond.
- Run Gold Ocean City preview.
- Confirm receipt appears.

## Path B — build fails
- Copy the GitHub Actions Gradle output.
- Classify the exact failure.
- Apply only the matching narrow fix.

No guessing. No private foundation exposure. Pure Intelligence name remains locked.
