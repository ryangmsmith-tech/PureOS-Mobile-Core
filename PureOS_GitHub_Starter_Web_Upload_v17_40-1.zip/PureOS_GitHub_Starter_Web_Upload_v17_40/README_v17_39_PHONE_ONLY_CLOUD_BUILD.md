# PureOS v17.39 — Phone-Only Cloud Build APK Core

This checkpoint exists because Ryan does not currently have a computer.

It adds a cloud build route so the Android debug APK can be attempted from a phone-driven workflow.

Main workflow:

```text
.github/workflows/pureos_android_debug_build.yml
```

The workflow searches the repo for the Android project, runs the debug APK Gradle task, and uploads the APK/build evidence as an artifact.

Honest status: this does not mean an APK has already been built. It means the no-computer build path is now prepared.
