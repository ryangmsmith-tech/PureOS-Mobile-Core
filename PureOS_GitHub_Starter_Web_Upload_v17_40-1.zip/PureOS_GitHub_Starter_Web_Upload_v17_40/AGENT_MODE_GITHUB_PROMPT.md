# Agent Mode / GitHub Copilot Prompt

Use this prompt after the repo is uploaded.

```text
You are working in the PureOS-Mobile-Core repository.

Goal: make the Android launch candidate build through GitHub Actions and produce a debug APK artifact.

Rules:
- Keep the intelligence layer named Pure Intelligence.
- Keep PureLang naming intact.
- Preserve Governor approval and safety gates.
- Primary Android project: android/PureOSLaunchCandidate.
- Primary workflow: .github/workflows/pureos_android_debug_build.yml.
- Do not claim success unless the workflow artifact contains an APK.

First task:
1. Inspect the GitHub Actions workflow and Android Gradle project.
2. Run or reason through the build.
3. If it fails, make the smallest fix.
4. Commit the fix on a branch named v17_41_cloud_build_fix.
5. Open a pull request with the build log summary and exact files changed.
```
