# PureOS Unified Master v17.40 — TenThread + Phone-Only Cloud Build Clean Master Core

This checkpoint merges and cleans:

1. `PureOS_Unified_Master_v17_22_FULL_TEN_THREAD_RESONANT_INTEGRATION_STACK.zip`
2. `PureOS_Unified_Master_v17_39_Phone_Only_Cloud_Build_APK_Core.zip`

## What this is

A cleaned combined master that keeps the ten-thread resonant integration stack and the phone-only GitHub Actions APK build path together.

## What was cleaned

- embedded `.zip` files skipped
- archive/source snapshot bloat skipped
- old source-doc lineage bloat skipped
- same-path duplicates resolved with the newest source winning
- exact duplicate same-path files skipped

## Important status

- Pure Intelligence naming preserved
- private foundation remains sealed
- server required by default: false
- APK built here: false
- phone/device tested here: false
- live Vulkan executed here: false

## Next move

Use the GitHub Actions cloud-build path if you do not have a computer:

1. Upload this project to GitHub.
2. Run `.github/workflows/pureos_android_debug_build.yml`.
3. Download the debug APK artifact if it builds.
4. Install on the S25 Ultra and run first-use proof.
5. If it fails, send the exact GitHub Actions build log or phone error back for v17.41.

## Merge stats

- source entries scanned: 24952
- final active file paths tracked before reports: 24904
- same-path replacements: 1
- same-path identical skipped: 0
- skipped bloat entries: 47
- read errors: 0
