# Upload With Termux

Use this when the GitHub website upload is annoying or blocked.

## One-time setup

```bash
pkg update -y
pkg install -y git openssh unzip
```

## Prepare the repo folder

Put `PureOS_GitHub_Starter_Web_Upload_v17_40.zip` in your phone Downloads folder, then run:

```bash
cd ~/storage/downloads
unzip PureOS_GitHub_Starter_Web_Upload_v17_40.zip -d pureos_github_starter
cd pureos_github_starter/PureOS_GitHub_Starter_Web_Upload_v17_40
```

## Push to GitHub

Create an empty GitHub repo first named `PureOS-Mobile-Core`, then run:

```bash
git init
git branch -M main
git add .
git commit -m "Add PureOS v17.40 phone cloud build starter"
git remote add origin https://github.com/rgsmithflames/PureOS-Mobile-Core.git
git push -u origin main
```

GitHub may ask for a username and token. If password login is rejected, create a GitHub personal access token and use the token as the password.
