# Upload From Android / Phone

## Best path: GitHub website starter upload

This starter package is kept small so it can be uploaded first while the full master archive stays as backup.

1. Download and unzip `PureOS_GitHub_Starter_Web_Upload_v17_40.zip` on your phone.
2. Open GitHub in your normal phone browser or GitHub app.
3. Create a new repository named `PureOS-Mobile-Core`.
4. Open the new repository.
5. Use **Add file → Upload files**.
6. Choose the unzipped starter folder/files.
7. Commit with this message:

```text
Add PureOS v17.40 phone cloud build starter
```

8. Go to **Actions**.
9. Enable workflows if GitHub asks.
10. Run **PureOS Android Debug APK Cloud Build**.

## If GitHub blocks the upload

Use the Termux command-line path in `docs/UPLOAD_WITH_TERMUX.md`.

## What to send back after the run

If the workflow fails, send:

- the failed step name
- the first red error block
- the bottom 30 lines of the log

If it succeeds, download the artifact named `PureOS-debug-apk-and-build-evidence` and check for an `.apk` file.
