# Project Map

## Runnable cloud-build target

- `android/PureOSLaunchCandidate/` — Android app shell for first GitHub Actions APK attempt.
- `android/PureOSLaunchCandidate/app/src/main/java/com/pureos/launch/` — Kotlin runtime and launch UI bridge.
- `android/PureOSLaunchCandidate/app/src/main/assets/` — v17 launch/test seed data.
- `android/PureOSLaunchCandidate/purelang/` — PureLang command seeds for the Android launch path.

## Automation

- `.github/workflows/pureos_android_debug_build.yml` — cloud debug APK workflow.
- `.github/copilot-instructions.md` — project rules for Copilot / coding agents.

## Handoff

- `AGENT_MODE_GITHUB_PROMPT.md` — paste this into GitHub Copilot/Coding Agent after upload.
- `docs/UPLOAD_FROM_ANDROID.md` — phone upload guide.
- `docs/UPLOAD_WITH_TERMUX.md` — command-line phone upload guide.
- `docs/FULL_MASTER_ARCHIVE_REFERENCE.md` — checksum reference for the full v17.40 archive.
- `docs/FULL_MASTER_SUMMARY.json` — size/count summary of the full archive contents.
