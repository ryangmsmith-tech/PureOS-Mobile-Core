# Full Master Archive Reference

Original archive:

`PureOS_Unified_Master_v17_40_TenThread_PhoneOnly_CloudBuild_Clean_Master_Core.zip`

SHA-256:

`fe35888d2f20be5eb37db95542cc65c48376b59a6f72fe6394f1623a4e6a18fa`

This starter repo is the clean GitHub launch path for the phone-only cloud build. Keep the original archive as the full master backup. Put the full archive in GitHub Releases or external storage later instead of committing it as a normal repo file.
