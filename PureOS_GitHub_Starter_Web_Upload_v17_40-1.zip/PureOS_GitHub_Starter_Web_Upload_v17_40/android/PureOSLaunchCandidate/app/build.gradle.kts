plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.pureos.launch"
    compileSdk = 35
    defaultConfig { applicationId = "com.pureos.launch"; minSdk = 26; targetSdk = 35; versionCode = 1717; versionName = "17.17-real-device-first-use-result-intake" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.core:core-ktx:1.13.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
