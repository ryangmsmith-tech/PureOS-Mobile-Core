package com.pureos.launch.status

/**
 * v17.34 status bridge for the first usable Android app handoff or exact runtime fix path.
 * This does not touch the private foundation.
 */
data class FirstUsableHandoffStatus(
    val checkpoint: String = "v17.34",
    val apkBuiltHere: Boolean = false,
    val apkInstalledHere: Boolean = false,
    val androidDeviceTestedHere: Boolean = false,
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false,
    val decision: String = "PENDING_REAL_DEVICE_EVIDENCE"
)

object FirstUsableHandoffStatusBridge_v17_34 {
    fun current(): FirstUsableHandoffStatus = FirstUsableHandoffStatus()

    fun classify(
        apkExists: Boolean,
        firstUsePassed: Boolean,
        exactFailure: String? = null
    ): String {
        if (!apkExists) return "MISSING_OR_UNVERIFIED_APK"
        if (firstUsePassed) return "FIRST_USABLE_APP_HANDOFF_READY"
        return exactFailure ?: "EXACT_RUNTIME_FIX_REQUIRED"
    }
}
