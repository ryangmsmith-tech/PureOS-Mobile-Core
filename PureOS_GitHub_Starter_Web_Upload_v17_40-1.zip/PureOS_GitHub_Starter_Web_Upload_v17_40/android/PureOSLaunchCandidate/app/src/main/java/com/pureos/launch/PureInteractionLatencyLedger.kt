package com.pureos.launch

import android.os.SystemClock

/**
 * Lightweight interaction latency marker store for v17.6.
 * It tracks visible UI milestones without waking Pure Intelligence unless requested.
 */
class PureInteractionLatencyLedger {
    private val markers = mutableListOf<PureLatencyMarker>()

    fun mark(name: String) {
        markers += PureLatencyMarker(name = name, timeMs = SystemClock.elapsedRealtime())
    }

    fun clear() {
        markers.clear()
    }

    fun summarize(): PureLatencySummary {
        val pairs = markers.zipWithNext().map { (a, b) ->
            PureLatencyDelta(from = a.name, to = b.name, deltaMs = b.timeMs - a.timeMs)
        }
        return PureLatencySummary(markers = markers.toList(), deltas = pairs)
    }
}

data class PureLatencyMarker(val name: String, val timeMs: Long)
data class PureLatencyDelta(val from: String, val to: String, val deltaMs: Long)
data class PureLatencySummary(
    val markers: List<PureLatencyMarker>,
    val deltas: List<PureLatencyDelta>
)
