package com.pureos.launch.status

data class FirstUsableSealStatusV1733(
    val version: String = "v17.33",
    val decision: String = "NEEDS_REAL_EVIDENCE",
    val apkExists: Boolean = false,
    val diamondWakePassed: Boolean = false,
    val worldPreviewOpened: Boolean = false,
    val receiptConfirmed: Boolean = false,
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object FirstUsableSealStatusBridgeV1733 {
    fun waiting(): FirstUsableSealStatusV1733 = FirstUsableSealStatusV1733()

    fun sealed(): FirstUsableSealStatusV1733 = FirstUsableSealStatusV1733(
        decision = "FIRST_USABLE_ANDROID_APP_SEAL_READY",
        apkExists = true,
        diamondWakePassed = true,
        worldPreviewOpened = true,
        receiptConfirmed = true,
        privateFoundationVisible = false,
        serverRequiredByDefault = false
    )

    fun exactFix(category: String): FirstUsableSealStatusV1733 = FirstUsableSealStatusV1733(
        decision = category.ifBlank { "EXACT_FIX_REQUIRED" },
        privateFoundationVisible = false,
        serverRequiredByDefault = false
    )

    fun label(status: FirstUsableSealStatusV1733): String = when (status.decision) {
        "FIRST_USABLE_ANDROID_APP_SEAL_READY" -> "First usable Android app seal is ready."
        "EXACT_BUILD_FIX_REQUIRED" -> "Exact build fix required."
        "EXACT_INSTALL_FIX_REQUIRED" -> "Exact install fix required."
        "EXACT_LAUNCH_FIX_REQUIRED" -> "Exact launch fix required."
        "EXACT_FIRST_USE_FIX_REQUIRED" -> "Exact first-use fix required."
        else -> "Waiting for real build/device evidence."
    }
}
