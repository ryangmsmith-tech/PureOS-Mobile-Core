package com.pureos.launch

/**
 * v17.17 real-device intake bridge.
 * This is intentionally local-first: it records what happened on Ryan's device
 * without requiring a server, internet, or private foundation access.
 */
object PureRealDeviceFirstUseResultBridge {
    fun commandSummary(command: String): String {
        val normalized = command.lowercase()
        return when {
            "pass" in normalized -> "First-use result marked PASS. Save launch receipt, APK checksum, and logcat evidence."
            "fail" in normalized -> "First-use result marked FAIL. Capture exact screen, receipt state, and logcat category for a narrow fix."
            else -> "First-use result intake ready. Expected checks: app launch, diamond wake, world preview, receipt visible."
        }
    }

    fun fixAdvice(): String = "If first-use fails, patch only the failing gate: launch, diamond wake, PureLang route, receipt store, or world preview."

    fun classify(
        appLaunched: Boolean,
        diamondWoke: Boolean,
        worldPreviewOpened: Boolean,
        receiptVisible: Boolean,
        crashFound: Boolean
    ): String {
        if (crashFound) return "fix_category=crash_or_exception"
        if (!appLaunched) return "fix_category=launch_failure"
        if (!diamondWoke) return "fix_category=pure_intelligence_diamond_wake"
        if (!worldPreviewOpened) return "fix_category=world_preview_route"
        if (!receiptVisible) return "fix_category=receipt_visibility_or_store"
        return "fix_category=pass_first_use_flow"
    }
}
