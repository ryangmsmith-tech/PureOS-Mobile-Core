package com.pureos.launch

/**
 * v17.20 first-use retest/pass-seal status bridge.
 * This is a UI-safe status model for System screen display; it does not claim pass
 * until real phone/emulator evidence is supplied.
 */
data class FirstUseV1720EvidenceStatus(
    val status: String,
    val decision: String?,
    val category: String?,
    val firstUsableCandidateReady: Boolean,
    val nextTarget: String
)

object FirstUseRetestPassSealBridge {
    fun pending(): FirstUseV1720EvidenceStatus = FirstUseV1720EvidenceStatus(
        status = "WAITING_FOR_REAL_RETEST_EVIDENCE",
        decision = null,
        category = null,
        firstUsableCandidateReady = false,
        nextTarget = "Run v17.20 first-use evidence collection on phone/emulator"
    )

    fun fromDecision(decision: String, category: String): FirstUseV1720EvidenceStatus {
        val pass = decision == "PASS_SEAL_READY" && category == "pass_seal_ready"
        return FirstUseV1720EvidenceStatus(
            status = if (pass) "PASS_SEAL_READY" else "EXACT_FIX_OR_MORE_EVIDENCE_REQUIRED",
            decision = decision,
            category = category,
            firstUsableCandidateReady = pass,
            nextTarget = if (pass) "v17.21 First Usable Android App Candidate Seal Core" else "v17.21 First-Use Retest Exact Fix Core"
        )
    }
}
