package com.pureos.launch

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

object PureCrashGuard {
    private var installed = false
    private var previousHandler: Thread.UncaughtExceptionHandler? = null

    fun install(context: Context) {
        if (installed) return
        installed = true
        val appContext = context.applicationContext
        previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            recordCrash(appContext, thread.name, throwable)
            val prior = previousHandler
            if (prior != null) {
                prior.uncaughtException(thread, throwable)
            } else {
                exitProcess(2)
            }
        }
    }

    private fun recordCrash(context: Context, threadName: String, throwable: Throwable) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val text = buildString {
            appendLine("PureOS crash marker v17.4")
            appendLine("time=$stamp")
            appendLine("thread=$threadName")
            appendLine("type=${throwable::class.java.name}")
            appendLine("message=${throwable.message ?: "<none>"}")
            appendLine(throwable.stackTraceToString())
        }
        runCatching { File(context.filesDir, "pureos_last_crash_v17_4.txt").writeText(text) }
    }
}
