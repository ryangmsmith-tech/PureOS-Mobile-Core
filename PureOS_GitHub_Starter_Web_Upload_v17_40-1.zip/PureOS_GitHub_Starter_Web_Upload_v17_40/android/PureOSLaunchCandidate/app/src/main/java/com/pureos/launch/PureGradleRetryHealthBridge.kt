package com.pureos.launch

/**
 * PureOS v17.9 Gradle retry health bridge.
 * This does not claim a real APK build by itself; it gives the app a clear place
 * to display sync/build retry evidence once Android Studio or CLI Gradle runs.
 */
data class PureGradleRetryStatus(
    val checkpoint: String,
    val syncStatus: String,
    val assembleDebugStatus: String,
    val apkCreated: Boolean,
    val retryCount: Int,
    val latestErrorCategory: String?,
    val privateFoundationAccess: Boolean = false,
    val serverRequired: Boolean = false
)

object PureGradleRetryHealthBridge {
    fun pending(): PureGradleRetryStatus = PureGradleRetryStatus(
        checkpoint = "v17.9",
        syncStatus = "pending_android_studio_or_cli_run",
        assembleDebugStatus = "pending_retry",
        apkCreated = false,
        retryCount = 0,
        latestErrorCategory = null
    )

    fun classify(errorText: String): String {
        val lower = errorText.lowercase()
        return when {
            "sdk location not found" in lower || "android sdk" in lower -> "ANDROID_SDK_PATH"
            "unresolved reference" in lower -> "KOTLIN_UNRESOLVED_REFERENCE"
            "manifest merger failed" in lower -> "MANIFEST_MERGE"
            "resource linking failed" in lower || "aapt" in lower -> "ANDROID_RESOURCE_LINK"
            "could not resolve" in lower || "dependency" in lower -> "DEPENDENCY_RESOLUTION"
            "compiledebugkotlin" in lower -> "KOTLIN_COMPILE"
            "assembledebug" in lower -> "ASSEMBLE_DEBUG"
            else -> "UNKNOWN_OR_NOT_RUN"
        }
    }
}
