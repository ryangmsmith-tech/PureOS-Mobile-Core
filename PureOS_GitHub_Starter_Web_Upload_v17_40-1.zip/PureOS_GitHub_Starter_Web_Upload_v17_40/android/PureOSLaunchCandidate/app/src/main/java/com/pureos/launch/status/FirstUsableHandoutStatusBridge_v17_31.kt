package com.pureos.launch.status

/**
 * v17.31 bridge for showing whether the user has produced real APK proof
 * or a real Gradle/build output that needs an exact fix.
 *
 * This is intentionally local-first and does not expose private foundation internals.
 */
data class FirstUsableHandoutStatusV1731(
    val checkpoint: String = "v17.31",
    val apkCreated: Boolean = false,
    val apkInstalled: Boolean = false,
    val appLaunched: Boolean = false,
    val pureIntelligenceDiamondWoke: Boolean = false,
    val goldOceanPreviewOpened: Boolean = false,
    val receiptConfirmed: Boolean = false,
    val exactBuildCategory: String = "pending_real_build_output",
    val serverRequiredByDefault: Boolean = false,
    val privateFoundationVisible: Boolean = false
) {
    fun nextAction(): String {
        if (!apkCreated) return "Run Android Studio build or capture exact Gradle output."
        if (!apkInstalled) return "Install APK on phone/emulator."
        if (!appLaunched) return "Launch Pure OS and collect logcat if needed."
        if (!pureIntelligenceDiamondWoke) return "Tap Pure Intelligence diamond and confirm wake state."
        if (!goldOceanPreviewOpened) return "Open Gold Ocean City preview."
        if (!receiptConfirmed) return "Confirm receipt appears or stores."
        return "First usable Android app proof is ready."
    }
}
