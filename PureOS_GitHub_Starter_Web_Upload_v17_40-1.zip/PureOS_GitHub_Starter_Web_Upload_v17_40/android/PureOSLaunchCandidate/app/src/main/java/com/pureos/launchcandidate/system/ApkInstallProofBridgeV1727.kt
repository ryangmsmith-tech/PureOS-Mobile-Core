package com.pureos.launchcandidate.system

/**
 * PureOS v17.27 APK install proof / exact build fix status bridge.
 * This is UI-facing status only. It does not claim install success without evidence.
 */
data class ApkInstallProofStatusV1727(
    val checkpoint: String = "v17.27",
    val apkExists: Boolean = false,
    val installed: Boolean = false,
    val launchCommandSent: Boolean = false,
    val classification: String = "awaiting_apk_install_proof_or_exact_build_fix",
    val nextAction: String = "Collect APK install proof or apply one exact build fix.",
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object ApkInstallProofBridgeV1727 {
    fun awaiting(): ApkInstallProofStatusV1727 = ApkInstallProofStatusV1727()

    fun fromClassification(classification: String): ApkInstallProofStatusV1727 {
        val next = when (classification) {
            "APK_LAUNCH_PROOF_READY" -> "Move to v17.28 first-use receipt proof."
            "APK_INSTALL_PROOF_READY" -> "Launch app and collect logcat proof."
            "APK_MISSING" -> "Run Gradle build or provide exact Gradle output."
            "ADB_DEVICE_NOT_READY" -> "Authorize device or start emulator."
            "RUNTIME_CRASH_ON_LAUNCH" -> "Patch exact crash stack trace only."
            "INSTALL_FAILED_SIGNATURE_CONFLICT" -> "Uninstall conflicting build or align signing."
            else -> "Collect missing evidence or apply one exact fix."
        }
        return ApkInstallProofStatusV1727(
            apkExists = classification == "APK_LAUNCH_PROOF_READY" || classification == "APK_INSTALL_PROOF_READY",
            installed = classification == "APK_LAUNCH_PROOF_READY" || classification == "APK_INSTALL_PROOF_READY",
            launchCommandSent = classification == "APK_LAUNCH_PROOF_READY",
            classification = classification,
            nextAction = next
        )
    }
}
