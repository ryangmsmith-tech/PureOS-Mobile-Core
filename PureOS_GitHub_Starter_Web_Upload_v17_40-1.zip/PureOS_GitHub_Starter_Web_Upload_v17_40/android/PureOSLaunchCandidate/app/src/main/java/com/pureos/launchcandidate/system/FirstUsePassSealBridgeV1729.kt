package com.pureos.launchcandidate.system

/**
 * PureOS v17.29 first-use pass seal / exact-fix status bridge.
 * This bridge is UI-facing only and must not claim proof without real device/emulator evidence.
 */
data class FirstUsePassSealStatusV1729(
    val checkpoint: String = "v17.29",
    val classification: String = "awaiting_evidence",
    val firstUsePassSealReady: Boolean = false,
    val exactFixRequired: Boolean = false,
    val exactFixCategory: String = "none",
    val nextAction: String = "Collect first-use evidence, then seal or patch exactly one category.",
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object FirstUsePassSealBridgeV1729 {
    fun awaiting(): FirstUsePassSealStatusV1729 = FirstUsePassSealStatusV1729()

    fun fromClassification(classification: String): FirstUsePassSealStatusV1729 {
        val pass = classification == "FIRST_USE_PASS_SEAL_READY"
        val fixCategory = when (classification) {
            "LAUNCH_CRASH_FIX_REQUIRED" -> "launch_crash"
            "DIAMOND_WAKE_FIX_REQUIRED" -> "diamond_wake"
            "PURE_INTELLIGENCE_STATE_FIX_REQUIRED" -> "pure_intelligence_state"
            "WORLD_PREVIEW_ROUTE_FIX_REQUIRED" -> "world_preview_route"
            "PURELANG_DISPATCH_FIX_REQUIRED" -> "purelang_dispatch"
            "RECEIPT_STORE_FIX_REQUIRED" -> "receipt_store"
            "RECEIPT_VISIBILITY_FIX_REQUIRED" -> "receipt_visibility"
            "PERFORMANCE_JANK_FIX_REQUIRED" -> "performance_jank"
            "EVIDENCE_REQUIRED" -> "evidence_required"
            else -> "unknown"
        }
        val next = when (classification) {
            "FIRST_USE_PASS_SEAL_READY" -> "Create v17.30 first usable Android app seal."
            "LAUNCH_CRASH_FIX_REQUIRED" -> "Patch exact launch stack trace only."
            "DIAMOND_WAKE_FIX_REQUIRED" -> "Patch center diamond wake bridge only."
            "PURE_INTELLIGENCE_STATE_FIX_REQUIRED" -> "Patch Pure Intelligence state transition only."
            "WORLD_PREVIEW_ROUTE_FIX_REQUIRED" -> "Patch Gold Ocean City preview route only."
            "PURELANG_DISPATCH_FIX_REQUIRED" -> "Patch world.preview PureLang dispatch only."
            "RECEIPT_STORE_FIX_REQUIRED" -> "Patch local receipt store only."
            "RECEIPT_VISIBILITY_FIX_REQUIRED" -> "Patch receipt UI visibility only."
            "PERFORMANCE_JANK_FIX_REQUIRED" -> "Patch animation/frame budget only."
            else -> "Collect complete first-use evidence."
        }
        return FirstUsePassSealStatusV1729(
            classification = classification,
            firstUsePassSealReady = pass,
            exactFixRequired = !pass,
            exactFixCategory = fixCategory,
            nextAction = next
        )
    }
}
