package com.pureos.launch

/**
 * v17.11 bridge for displaying APK install/launch retry status inside the System screen.
 * This is local-only evidence metadata; it does not expose private foundation internals.
 */
data class PureInstallLaunchResult(
    val apkPath: String = "app/build/outputs/apk/debug/app-debug.apk",
    val apkExists: Boolean = false,
    val adbDeviceDetected: Boolean = false,
    val installResult: String = "not_run",
    val launchResult: String = "not_run",
    val fatalExceptionFound: Boolean = false,
    val nextAction: String = "Run v17.11 install/launch retry on a real device or emulator."
)

object PureInstallLaunchResultBridge {
    fun pending(): PureInstallLaunchResult = PureInstallLaunchResult()

    fun summarize(result: PureInstallLaunchResult): String {
        return buildString {
            appendLine("PureOS v17.11 Install/Launch Status")
            appendLine("APK: ${result.apkPath}")
            appendLine("APK exists: ${result.apkExists}")
            appendLine("ADB device: ${result.adbDeviceDetected}")
            appendLine("Install: ${result.installResult}")
            appendLine("Launch: ${result.launchResult}")
            appendLine("Fatal exception: ${result.fatalExceptionFound}")
            appendLine("Next: ${result.nextAction}")
        }
    }
}
