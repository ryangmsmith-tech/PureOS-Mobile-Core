package com.pureos.launch

/**
 * v17.19 bridge: shows whether the first-use path is ready to seal as PASS
 * or whether a single narrow fix category must be applied and retested.
 */
data class FirstUseV1719Plan(
    val action: String,
    val category: String,
    val nextTarget: String,
    val retestRequired: Boolean,
    val allowedPatchScope: List<String>
)

object FirstUsePassSealOrNarrowFixBridge {
    fun fromDecision(decision: String, category: String, allowedScope: List<String>): FirstUseV1719Plan {
        return when (decision) {
            "PASS_SEAL_READY" -> FirstUseV1719Plan(
                action = "CREATE_PASS_SEAL_LEDGER",
                category = "pass_seal_ready",
                nextTarget = "v17.20 First-Use Pass Seal Evidence + Launch Proof Core",
                retestRequired = false,
                allowedPatchScope = emptyList()
            )
            "EXACT_FIX_REQUIRED" -> FirstUseV1719Plan(
                action = "APPLY_ONE_NARROW_FIX_THEN_RETEST",
                category = category,
                nextTarget = "v17.20 First-Use Retest After Narrow Fix Core",
                retestRequired = true,
                allowedPatchScope = allowedScope
            )
            else -> FirstUseV1719Plan(
                action = "COLLECT_MORE_EVIDENCE",
                category = "incomplete_result",
                nextTarget = "repeat v17.18 evidence collection",
                retestRequired = true,
                allowedPatchScope = emptyList()
            )
        }
    }
}
