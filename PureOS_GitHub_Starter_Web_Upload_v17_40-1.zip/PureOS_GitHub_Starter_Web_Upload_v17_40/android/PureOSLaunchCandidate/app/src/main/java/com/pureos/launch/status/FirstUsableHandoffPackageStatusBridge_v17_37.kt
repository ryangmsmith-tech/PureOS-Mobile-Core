package com.pureos.launch.status

/**
 * PureOS v17.37 first usable app handoff package status bridge.
 * UI-safe status only. It exposes no private foundation internals.
 */
data class FirstUsableHandoffPackageStatusV1737(
    val checkpoint: String = "v17.37",
    val result: String = "REAL_EVIDENCE_MISSING",
    val category: String = "missing_real_evidence",
    val apkProof: Boolean = false,
    val installProof: Boolean = false,
    val launchProof: Boolean = false,
    val firstUseProof: Boolean = false,
    val handoffPackageReady: Boolean = false,
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object FirstUsableHandoffPackageStatusBridgeV1737 {
    fun missingEvidence(): FirstUsableHandoffPackageStatusV1737 = FirstUsableHandoffPackageStatusV1737()

    fun ready(): FirstUsableHandoffPackageStatusV1737 = FirstUsableHandoffPackageStatusV1737(
        result = "FIRST_USABLE_HANDOFF_PACKAGE_READY",
        category = "first_use_handoff_passed",
        apkProof = true,
        installProof = true,
        launchProof = true,
        firstUseProof = true,
        handoffPackageReady = true
    )

    fun finalFixRequired(category: String): FirstUsableHandoffPackageStatusV1737 =
        FirstUsableHandoffPackageStatusV1737(
            result = "FINAL_RUNTIME_FIX_REQUIRED",
            category = category
        )

    fun retestReady(category: String): FirstUsableHandoffPackageStatusV1737 =
        FirstUsableHandoffPackageStatusV1737(
            result = "FINAL_RUNTIME_FIX_RETEST_READY",
            category = category
        )
}
