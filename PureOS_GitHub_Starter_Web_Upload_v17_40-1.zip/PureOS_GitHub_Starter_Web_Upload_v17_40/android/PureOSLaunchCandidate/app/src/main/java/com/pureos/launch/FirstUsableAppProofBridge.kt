package com.pureos.launch

/**
 * v17.23 bridge for first usable Android app proof.
 * This does not perform privileged actions. It summarizes local proof state for the System UI.
 */
data class FirstUsableAppProofStatus(
    val version: String = "v17.23",
    val apkExists: Boolean = false,
    val installPassed: Boolean = false,
    val launchPassed: Boolean = false,
    val diamondWakePassed: Boolean = false,
    val goldOceanCityPreviewPassed: Boolean = false,
    val receiptVisiblePassed: Boolean = false,
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
) {
    val firstUsableReady: Boolean
        get() = apkExists && installPassed && launchPassed && diamondWakePassed && goldOceanCityPreviewPassed && receiptVisiblePassed && !privateFoundationVisible && !serverRequiredByDefault

    val nextAction: String
        get() = if (firstUsableReady) {
            "Create v17.24 first usable Android app seal."
        } else {
            "Collect exact evidence and apply only one narrow fix category."
        }
}

object FirstUsableAppProofBridge {
    fun pending(): FirstUsableAppProofStatus = FirstUsableAppProofStatus()

    fun classify(status: FirstUsableAppProofStatus): String {
        if (!status.apkExists) return "apk_missing"
        if (!status.installPassed) return "install_failed"
        if (!status.launchPassed) return "launch_crash"
        if (!status.diamondWakePassed) return "diamond_wake_failed"
        if (!status.goldOceanCityPreviewPassed) return "world_preview_route_failed"
        if (!status.receiptVisiblePassed) return "receipt_store_or_visibility_failed"
        return if (status.firstUsableReady) "pass_first_usable_flow" else "manual_checks_pending"
    }
}
