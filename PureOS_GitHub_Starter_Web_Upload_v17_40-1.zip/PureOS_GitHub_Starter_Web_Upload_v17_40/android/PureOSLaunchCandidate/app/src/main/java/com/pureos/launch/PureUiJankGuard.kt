package com.pureos.launch

/**
 * PureOS v17.7 UI jank guard.
 * Rule: preserve instant input feedback before expensive prismatic effects.
 */
object PureUiJankGuard {
    fun shouldReduceEffects(
        framesOverBudget: Int,
        thermalWarning: Boolean,
        batterySaver: Boolean
    ): Boolean {
        return framesOverBudget >= 3 || thermalWarning || batterySaver
    }

    fun allowedEffectSet(reduced: Boolean): List<String> {
        return if (reduced) {
            listOf("instant_touch_glow", "single_prism_edge", "no_heavy_blur", "short_route_morph")
        } else {
            listOf("touch_shockwave", "prismatic_glass", "soft_blur", "route_morph", "diamond_refraction")
        }
    }
}
