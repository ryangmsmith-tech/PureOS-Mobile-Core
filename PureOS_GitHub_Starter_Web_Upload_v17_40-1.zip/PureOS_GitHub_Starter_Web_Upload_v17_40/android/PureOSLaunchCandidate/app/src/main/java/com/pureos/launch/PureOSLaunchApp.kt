package com.pureos.launch

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PureOSLaunchApp() {
    var route by remember { mutableStateOf(PureRoute.Home) }
    var mode by remember { mutableStateOf(PureThemeMode.DarkSacred) }
    var quickSettings by remember { mutableStateOf(false) }
    val receipts = remember { ReceiptStore() }
    val pureLang = remember { PureLangRunner(receipts) }
    val backgroundTasks = remember { PureBackgroundTaskQueue(receipts, pureLang) }
    val brain = remember { PureIntelligenceEngine(receipts, pureLang, backgroundTasks) }
    val tokens = PureTokens.from(mode)

    Box(
        Modifier.fillMaxSize().background(tokens.background).pointerInput(Unit) {
            detectDragGesturesAfterLongPress(
                onDragStart = { quickSettings = true },
                onDragEnd = {},
                onDragCancel = {},
                onDrag = { change, drag -> if (drag.y > 8f) quickSettings = true; change.consume() }
            )
        }
    ) {
        GeometryBackground(tokens)
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            TopBar(tokens) { mode = if (mode == PureThemeMode.DarkSacred) PureThemeMode.LightSacred else PureThemeMode.DarkSacred }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.weight(1f)) {
                when(route) {
                    PureRoute.Home -> HomeScreen(tokens, brain, pureLang, receipts) { route = it }
                    PureRoute.World -> WorldScreen(tokens, pureLang, receipts)
                    PureRoute.Chat -> ChatScreen(tokens, brain, receipts)
                    PureRoute.Codex -> SimpleListScreen(tokens, "CODEX", listOf("Genesis Codex", "Gold Ocean City", "Horror Continent", "Storm Continent"))
                    PureRoute.Profile -> SimpleListScreen(tokens, "PROFILE", listOf("Creator profile", "Level 50 placeholder", "Achievements"))
                    PureRoute.PureLang -> PureLangScreen(tokens, pureLang, receipts)
                    PureRoute.System -> SystemScreen(tokens, brain, pureLang, receipts)
                }
            }
            PrismaticBottomBar(tokens, route, { route = it }, { brain.wake("center_diamond_tap"); route = PureRoute.Chat })
        }
        AnimatedVisibility(quickSettings) { QuickSettingsPanel(tokens, { quickSettings = false }, { mode = if (mode == PureThemeMode.DarkSacred) PureThemeMode.LightSacred else PureThemeMode.DarkSacred }) }
    }
}

@Composable
fun TopBar(tokens: PureTokens, toggleTheme: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("☰", color = tokens.gold, fontSize = 28.sp)
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("PURE OS", color = tokens.gold, fontSize = 30.sp, letterSpacing = 5.sp, fontWeight = FontWeight.Light)
            Text("● PURE INTELLIGENCE READY", color = tokens.accent, fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = toggleTheme) { Text("Mode", color = tokens.gold) }
    }
}

@Composable
fun HomeScreen(tokens: PureTokens, brain: PureIntelligenceEngine, pureLang: PureLangRunner, receipts: ReceiptStore, navigate: (PureRoute)->Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { StatusCard(tokens, brain.stateLabel) }
        item { FeaturedWorld(tokens) { pureLang.run("world.preview \"gold_ocean_city\""); navigate(PureRoute.World) } }
        item { IconGrid(tokens, navigate) }
        item { ReceiptCard(tokens, receipts.lastReceipt()) }
    }
}

@Composable
fun StatusCard(tokens: PureTokens, brainState: String) = GlassCard(tokens) {
    Column(Modifier.padding(16.dp)) {
        Row { Text("SYSTEM STATUS", color=tokens.text, fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("● OPTIMAL", color=tokens.safe, fontSize=12.sp) }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            MiniStatus(tokens, "Server", "No")
            MiniStatus(tokens, "Foundation", "Sealed")
            MiniStatus(tokens, "Brain", brainState)
        }
    }
}

@Composable
fun MiniStatus(tokens: PureTokens, title: String, value: String) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("◇", color=tokens.accent, fontSize=24.sp); Text(title, color=tokens.muted, fontSize=11.sp); Text(value, color=tokens.safe, fontSize=12.sp) } }

@Composable
fun FeaturedWorld(tokens: PureTokens, enter: ()->Unit) = GlassCard(tokens) {
    Column(Modifier.padding(16.dp)) {
        Text("FEATURED WORLD", color=tokens.gold, fontSize=12.sp)
        Text("GOLD OCEAN CITY", color=tokens.gold, fontSize=24.sp, letterSpacing=1.sp)
        Text("The Sacred City of Pure", color=tokens.text)
        Text("A living world of consciousness, creation, and connection.", color=tokens.muted, fontSize=13.sp)
        Spacer(Modifier.height(10.dp))
        Button(onClick=enter, colors=ButtonDefaults.buttonColors(containerColor=tokens.gold.copy(alpha=.25f))) { Text("ENTER WORLD") }
    }
}

@Composable
fun IconGrid(tokens: PureTokens, navigate: (PureRoute)->Unit) {
    val routes = listOf(PureRoute.World, PureRoute.Chat, PureRoute.Codex, PureRoute.PureLang, PureRoute.System, PureRoute.Profile)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        routes.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { route -> SacredIcon(tokens, route, Modifier.weight(1f)) { navigate(route) } }
            }
        }
    }
}

@Composable
fun SacredIcon(tokens: PureTokens, route: PureRoute, modifier: Modifier, click: ()->Unit) {
    Surface(onClick=click, shape=RoundedCornerShape(22.dp), color=tokens.card.copy(alpha=.55f), border=androidx.compose.foundation.BorderStroke(1.dp, tokens.prism), modifier=modifier.height(90.dp)) {
        Column(Modifier.fillMaxSize(), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
            DiamondGlyph(tokens, route.name.take(1))
            Text(route.label, color=tokens.text, fontSize=11.sp, textAlign=TextAlign.Center)
        }
    }
}

@Composable
fun DiamondGlyph(tokens: PureTokens, label: String) {
    Box(Modifier.size(38.dp), contentAlignment=Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) { val path=Path(); path.moveTo(size.width/2, 2f); path.lineTo(size.width-4f, size.height/2); path.lineTo(size.width/2, size.height-2f); path.lineTo(4f, size.height/2); path.close(); drawPath(path, tokens.gold, style=Stroke(2.4f)); drawCircle(tokens.gold.copy(alpha=.18f), style=Stroke(1.2f)) }
        Text(label, color=tokens.gold, fontSize=12.sp)
    }
}

@Composable
fun PrismaticBottomBar(tokens: PureTokens, route: PureRoute, navigate: (PureRoute)->Unit, wake: ()->Unit) {
    Surface(shape=RoundedCornerShape(32.dp), color=tokens.card.copy(alpha=.65f), border=androidx.compose.foundation.BorderStroke(1.dp, tokens.prism), modifier=Modifier.fillMaxWidth().height(82.dp)) {
        Row(Modifier.fillMaxSize().padding(horizontal=10.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceEvenly) {
            BottomItem(tokens, PureRoute.Home, route==PureRoute.Home) { navigate(PureRoute.Home) }
            BottomItem(tokens, PureRoute.World, route==PureRoute.World) { navigate(PureRoute.World) }
            Surface(onClick=wake, shape=CircleShape, color=tokens.accent.copy(alpha=.16f), border=androidx.compose.foundation.BorderStroke(1.5.dp, tokens.prism), modifier=Modifier.size(72.dp)) { Box(contentAlignment=Alignment.Center) { Text("◆", color=tokens.accent, fontSize=42.sp) } }
            BottomItem(tokens, PureRoute.Codex, route==PureRoute.Codex) { navigate(PureRoute.Codex) }
            BottomItem(tokens, PureRoute.Profile, route==PureRoute.Profile) { navigate(PureRoute.Profile) }
        }
    }
}

@Composable
fun BottomItem(tokens: PureTokens, r: PureRoute, active: Boolean, click: ()->Unit) { TextButton(onClick=click) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text(if(active) "◆" else "◇", color=if(active) tokens.gold else tokens.muted); Text(r.label, color=if(active) tokens.gold else tokens.muted, fontSize=10.sp) } } }

@Composable
fun WorldScreen(tokens: PureTokens, runner: PureLangRunner, receipts: ReceiptStore) { ScreenTitle(tokens, "WORLD", "Explore. Connect. Belong."); FeaturedWorld(tokens) { runner.run("world.preview \"gold_ocean_city\"") }; ReceiptCard(tokens, receipts.lastReceipt()) }
@Composable
fun ChatScreen(tokens: PureTokens, brain: PureIntelligenceEngine, receipts: ReceiptStore) { var input by remember { mutableStateOf("Open Gold Ocean City preview") }; ScreenTitle(tokens,"PURE INTELLIGENCE","Tap diamond. Give task. Receipt saved."); GlassCard(tokens){ Column(Modifier.padding(16.dp)){ OutlinedTextField(input, {input=it}, label={Text("Task")}, modifier=Modifier.fillMaxWidth()); Row(Modifier.padding(top=8.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(onClick={brain.handleUserTask(input)}){Text("Run")}; OutlinedButton(onClick={brain.approveBackgroundTask(input); brain.runBackgroundTick()}){Text("Background")}; TextButton(onClick={brain.sleep()}){Text("Sleep")}} }}; ReceiptCard(tokens, receipts.lastReceipt()) }
@Composable
fun PureLangScreen(tokens: PureTokens, runner: PureLangRunner, receipts: ReceiptStore) { var cmd by remember { mutableStateOf("world.preview \"gold_ocean_city\"") }; ScreenTitle(tokens,"PURELANG","Public command layer"); GlassCard(tokens){ Column(Modifier.padding(16.dp)){ OutlinedTextField(cmd, {cmd=it}, label={Text("Command")}, modifier=Modifier.fillMaxWidth()); Button(onClick={runner.run(cmd)}, modifier=Modifier.padding(top=8.dp)){Text("Execute")}}}; ReceiptCard(tokens, receipts.lastReceipt()) }
@Composable
fun SystemScreen(tokens: PureTokens, brain: PureIntelligenceEngine, runner: PureLangRunner, receipts: ReceiptStore) { ScreenTitle(tokens,"SYSTEM","Receipts, diagnostics, and section health"); StatusCard(tokens, brain.stateLabel); GlassCard(tokens){ Column(Modifier.padding(12.dp)){ Button(onClick={brain.runFirstUseSmoke()}){Text("Run First-Use Smoke Test")}; Spacer(Modifier.height(8.dp)); OutlinedButton(onClick={runner.run("diagnostics.status")}){Text("Diagnostics Status")}; Spacer(Modifier.height(8.dp)); OutlinedButton(onClick={runner.run("logcat.help")}){Text("Logcat Help")}; Spacer(Modifier.height(8.dp)); Text("Receipts", color=tokens.gold, fontWeight=FontWeight.Bold) } }; SimpleList(tokens, receipts.all().map { it.summary }.ifEmpty { listOf("No receipts yet") }) }
@Composable
fun SimpleListScreen(tokens: PureTokens, title: String, rows: List<String>) { ScreenTitle(tokens, title, "v17.0 launch test screen"); SimpleList(tokens, rows) }
@Composable
fun SimpleList(tokens: PureTokens, rows: List<String>) = GlassCard(tokens) { Column(Modifier.padding(10.dp)) { rows.forEach { Text("◇  $it", color=tokens.text, modifier=Modifier.padding(8.dp)) } } }
@Composable
fun ScreenTitle(tokens: PureTokens, title: String, subtitle: String) { Column(Modifier.padding(vertical=8.dp)) { Text(title, color=tokens.gold, fontSize=26.sp, letterSpacing=2.sp); Text(subtitle, color=tokens.muted) } }
@Composable
fun ReceiptCard(tokens: PureTokens, receipt: Receipt?) = GlassCard(tokens) { Text(receipt?.summary ?: "No receipt yet. Run a command to create one.", color=tokens.text, modifier=Modifier.padding(14.dp)) }
@Composable
fun GlassCard(tokens: PureTokens, content: @Composable ()->Unit) { Surface(shape=RoundedCornerShape(24.dp), color=tokens.card.copy(alpha=.62f), border=androidx.compose.foundation.BorderStroke(1.dp, tokens.border), modifier=Modifier.fillMaxWidth()) { content() } }
@Composable
fun QuickSettingsPanel(tokens: PureTokens, close: ()->Unit, toggleTheme: ()->Unit) { Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.22f))) { Surface(shape=RoundedCornerShape(bottomStart=34.dp,bottomEnd=34.dp), color=tokens.card.copy(alpha=.88f), border=androidx.compose.foundation.BorderStroke(1.dp,tokens.prism), modifier=Modifier.fillMaxWidth().height(360.dp)) { Column(Modifier.padding(20.dp)) { Row { Text("QUICK SETTINGS", color=tokens.text, fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton(onClick=close){Text("Close", color=tokens.gold)} }; QuickTile(tokens,"Wi‑Fi"); QuickTile(tokens,"Bluetooth"); QuickTile(tokens,"Theme", toggleTheme); QuickTile(tokens,"Pure Intelligence") } } } }
@Composable
fun QuickTile(tokens: PureTokens, label: String, click: ()->Unit = {}) { Surface(onClick=click, shape=RoundedCornerShape(18.dp), color=tokens.card.copy(alpha=.45f), border=androidx.compose.foundation.BorderStroke(1.dp,tokens.prism), modifier=Modifier.fillMaxWidth().padding(vertical=4.dp).height(48.dp)) { Box(contentAlignment=Alignment.CenterStart, modifier=Modifier.padding(start=16.dp)) { Text(label, color=tokens.text) } } }
@Composable
fun GeometryBackground(tokens: PureTokens) { Canvas(Modifier.fillMaxSize()) { val c=Offset(size.width/2, size.height*.23f); for(i in 1..8) drawCircle(tokens.gold.copy(alpha=.045f), radius=i*52f, center=c, style=Stroke(1.1f)) } }

enum class PureRoute(val label: String) { Home("Home"), World("World"), Chat("Chat"), Codex("Codex"), Profile("Profile"), PureLang("PureLang"), System("System") }
enum class PureThemeMode { DarkSacred, LightSacred }

data class PureTokens(val gold: Color, val accent: Color, val safe: Color, val text: Color, val muted: Color, val card: Color, val border: Color, val prism: Color, val background: Brush) {
    companion object { fun from(mode: PureThemeMode): PureTokens = if(mode==PureThemeMode.DarkSacred) PureTokens(Color(0xFFFFC76A), Color(0xFF62A8FF), Color(0xFF6CFF9E), Color(0xFFF8F4EA), Color(0xFFB9C0CD), Color(0xFF06101C), Color(0x66FFC76A), Color(0x99BEEAFF), Brush.verticalGradient(listOf(Color(0xFF02050B), Color(0xFF061220), Color(0xFF02050B)))) else PureTokens(Color(0xFFB9822B), Color(0xFF347CFF), Color(0xFF16884B), Color(0xFF2B2B2B), Color(0xFF6E6E6E), Color(0xFFF9F6EF), Color(0x66B9822B), Color(0x99D7B5FF), Brush.verticalGradient(listOf(Color(0xFFFFFCF4), Color(0xFFF3F6FF), Color(0xFFFFFCF4)))) }
}
