package com.pureos.launch

import android.os.SystemClock

/**
 * PureOS v17.7 latency optimizer scaffold.
 * Keeps visual beauty, but protects tap response first.
 */
class PureInteractionLatencyOptimizer(
    private var activeProfile: PureMotionBudgetProfile = PureAnimationBudget.chooseProfile("mobile_low")
) {
    private var lastInteractionMs: Long = 0L
    private var reducedEffects: Boolean = false

    fun setProfile(profileName: String) {
        activeProfile = PureAnimationBudget.chooseProfile(profileName)
    }

    fun onTouchStart(route: String): PureLatencyBudgetDecision {
        lastInteractionMs = SystemClock.elapsedRealtime()
        return PureLatencyBudgetDecision(
            route = route,
            profile = activeProfile.name,
            targetHz = activeProfile.targetHz,
            frameBudgetMs = activeProfile.frameBudgetMs,
            reducedEffects = reducedEffects,
            privateFoundationAccess = false,
            serverRequired = false
        )
    }

    fun onFramePressure(framesOverBudget: Int): PureLatencyBudgetDecision {
        reducedEffects = framesOverBudget >= 3
        return PureLatencyBudgetDecision(
            route = "frame_pressure_guard",
            profile = activeProfile.name,
            targetHz = activeProfile.targetHz,
            frameBudgetMs = activeProfile.frameBudgetMs,
            reducedEffects = reducedEffects,
            privateFoundationAccess = false,
            serverRequired = false
        )
    }

    fun diamondWakeBudgetMs(): Int = activeProfile.maxDiamondWakeMs
    fun appRouteTransitionBudgetMs(): Int = activeProfile.maxTransitionMs
    fun quickSettingsBudgetMs(): Int = activeProfile.maxQuickSettingsOpenMs
}

data class PureLatencyBudgetDecision(
    val route: String,
    val profile: String,
    val targetHz: Int,
    val frameBudgetMs: Double,
    val reducedEffects: Boolean,
    val privateFoundationAccess: Boolean,
    val serverRequired: Boolean
)
