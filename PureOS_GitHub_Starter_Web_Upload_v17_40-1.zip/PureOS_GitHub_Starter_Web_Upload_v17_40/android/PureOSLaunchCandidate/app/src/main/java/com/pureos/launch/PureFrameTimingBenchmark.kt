package com.pureos.launch

import android.os.SystemClock
import android.view.Choreographer
import java.util.ArrayDeque
import kotlin.math.roundToInt

/**
 * PureOS v17.6 frame timing scaffold.
 * Measures UI frame intervals while Pure OS is running.
 * This is intentionally local-only and does not access the private foundation.
 */
class PureFrameTimingBenchmark(
    private val maxSamples: Int = 240
) : Choreographer.FrameCallback {
    private val frameIntervalsMs = ArrayDeque<Double>()
    private var running: Boolean = false
    private var lastFrameNanos: Long = 0L
    private var startedAtMs: Long = 0L

    fun start() {
        if (running) return
        running = true
        lastFrameNanos = 0L
        startedAtMs = SystemClock.elapsedRealtime()
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun stop(): PureFrameTimingReport {
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
        return report()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (lastFrameNanos != 0L) {
            val deltaMs = (frameTimeNanos - lastFrameNanos) / 1_000_000.0
            frameIntervalsMs.addLast(deltaMs)
            while (frameIntervalsMs.size > maxSamples) frameIntervalsMs.removeFirst()
        }
        lastFrameNanos = frameTimeNanos
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun markInteraction(label: String): PureInteractionMarker {
        return PureInteractionMarker(
            label = label,
            timestampMs = SystemClock.elapsedRealtime(),
            state = "marker_saved_local_only"
        )
    }

    fun report(): PureFrameTimingReport {
        val values = frameIntervalsMs.toList()
        val average = if (values.isEmpty()) 0.0 else values.average()
        val over16 = values.count { it > 16.67 }
        val over33 = values.count { it > 33.34 }
        val fpsEstimate = if (average <= 0.0) 0 else (1000.0 / average).roundToInt()
        return PureFrameTimingReport(
            sampleCount = values.size,
            averageFrameMs = average,
            estimatedFps = fpsEstimate,
            framesOver16ms = over16,
            framesOver33ms = over33,
            durationMs = SystemClock.elapsedRealtime() - startedAtMs,
            privateFoundationAccess = false,
            serverRequired = false
        )
    }
}

data class PureInteractionMarker(
    val label: String,
    val timestampMs: Long,
    val state: String
)

data class PureFrameTimingReport(
    val sampleCount: Int,
    val averageFrameMs: Double,
    val estimatedFps: Int,
    val framesOver16ms: Int,
    val framesOver33ms: Int,
    val durationMs: Long,
    val privateFoundationAccess: Boolean,
    val serverRequired: Boolean
) {
    fun toReceiptText(): String = """
        PureOS Frame Timing Report
        samples=$sampleCount
        averageFrameMs=$averageFrameMs
        estimatedFps=$estimatedFps
        framesOver16ms=$framesOver16ms
        framesOver33ms=$framesOver33ms
        durationMs=$durationMs
        privateFoundationAccess=$privateFoundationAccess
        serverRequired=$serverRequired
    """.trimIndent()
}
