package com.pureos.launch

/**
 * v17.18 bridge: converts first-use evidence into a pass-seal or exact-fix status.
 * This is UI-safe and does not touch the private foundation.
 */
data class FirstUsePassSealStatus(
    val decision: String,
    val category: String,
    val nextTarget: String,
    val canSealPass: Boolean,
    val allowedPatchScope: List<String>
)

object FirstUseExactFixOrPassSealBridge {
    fun decide(
        appLaunched: Boolean,
        crashed: Boolean,
        diamondWake: Boolean,
        worldPreviewOpened: Boolean,
        receiptVisible: Boolean,
        receiptSaved: Boolean
    ): FirstUsePassSealStatus {
        if (appLaunched && !crashed && diamondWake && worldPreviewOpened && receiptVisible && receiptSaved) {
            return FirstUsePassSealStatus(
                decision = "PASS_SEAL_READY",
                category = "pass_seal_ready",
                nextTarget = "v17.19 First-Use Pass Seal + Android Proof Ledger Core",
                canSealPass = true,
                allowedPatchScope = emptyList()
            )
        }
        if (!appLaunched || crashed) {
            return FirstUsePassSealStatus(
                decision = "EXACT_FIX_REQUIRED",
                category = "launch_failure",
                nextTarget = "v17.19 First-Use Narrow Fix Apply + Retest Core",
                canSealPass = false,
                allowedPatchScope = listOf("MainActivity.kt", "AndroidManifest.xml", "theme/style resources")
            )
        }
        if (!diamondWake) {
            return FirstUsePassSealStatus(
                decision = "EXACT_FIX_REQUIRED",
                category = "diamond_wake_failure",
                nextTarget = "v17.19 First-Use Narrow Fix Apply + Retest Core",
                canSealPass = false,
                allowedPatchScope = listOf("PureIntelligenceWakeLoop.kt", "PrismaticDiamond button route handler", "state bridge")
            )
        }
        if (!worldPreviewOpened) {
            return FirstUsePassSealStatus(
                decision = "EXACT_FIX_REQUIRED",
                category = "world_preview_route_failure",
                nextTarget = "v17.19 First-Use Narrow Fix Apply + Retest Core",
                canSealPass = false,
                allowedPatchScope = listOf("PureLangCommandRunner.kt", "WorldPreview route bridge", "navigation host")
            )
        }
        if (!receiptVisible) {
            return FirstUsePassSealStatus(
                decision = "EXACT_FIX_REQUIRED",
                category = "receipt_visibility_failure",
                nextTarget = "v17.19 First-Use Narrow Fix Apply + Retest Core",
                canSealPass = false,
                allowedPatchScope = listOf("LocalReceiptStore.kt", "receipt UI card", "System receipt bridge")
            )
        }
        return FirstUsePassSealStatus(
            decision = "EXACT_FIX_REQUIRED",
            category = "receipt_store_failure",
            nextTarget = "v17.19 First-Use Narrow Fix Apply + Retest Core",
            canSealPass = false,
            allowedPatchScope = listOf("local receipt persistence only")
        )
    }
}
