package com.pureos.launch.status

data class UserDeviceEvidenceStatusV1732(
    val version: String = "v17.32",
    val apkProofReceived: Boolean = false,
    val installProofReceived: Boolean = false,
    val launchProofReceived: Boolean = false,
    val firstUseReceiptConfirmed: Boolean = false,
    val decisionCategory: String = "WAITING_FOR_REAL_EVIDENCE",
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object UserDeviceEvidenceStatusBridgeV1732 {
    fun waiting(): UserDeviceEvidenceStatusV1732 = UserDeviceEvidenceStatusV1732()

    fun fromAnalyzerCategory(category: String): UserDeviceEvidenceStatusV1732 {
        val normalized = category.trim().ifEmpty { "WAITING_FOR_REAL_EVIDENCE" }
        return UserDeviceEvidenceStatusV1732(
            apkProofReceived = normalized.contains("APK") || normalized.contains("FIRST_USABLE"),
            installProofReceived = normalized.contains("INSTALL") || normalized.contains("FIRST_USABLE"),
            launchProofReceived = normalized.contains("LAUNCH") || normalized.contains("FIRST_USABLE"),
            firstUseReceiptConfirmed = normalized == "FIRST_USABLE_APP_SEAL_READY",
            decisionCategory = normalized,
            privateFoundationVisible = false,
            serverRequiredByDefault = false
        )
    }

    fun nextInstruction(status: UserDeviceEvidenceStatusV1732): String {
        return when (status.decisionCategory) {
            "FIRST_USABLE_APP_SEAL_READY" -> "Create first usable Android app seal."
            "KOTLIN_COMPILE_ERROR_EXACT_FIX_REQUIRED" -> "Patch the exact Kotlin compile error only."
            "COMPOSE_CONFIGURATION_ERROR_EXACT_FIX_REQUIRED" -> "Patch Compose configuration only."
            "MANIFEST_OR_NAMESPACE_ERROR_EXACT_FIX_REQUIRED" -> "Patch manifest or namespace only."
            "RESOURCE_ERROR_EXACT_FIX_REQUIRED" -> "Patch Android resource error only."
            "INSTALL_FAILED_EXACT_FIX_REQUIRED" -> "Patch exact install failure only."
            "LAUNCH_CRASH_EXACT_FIX_REQUIRED" -> "Patch exact launch crash only."
            "FIRST_USE_EXACT_FIX_REQUIRED" -> "Patch exact first-use failure only."
            else -> "Collect real Android Studio build output or device evidence."
        }
    }
}
