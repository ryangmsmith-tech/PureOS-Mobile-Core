package com.pureos.launchcandidate.system

/**
 * PureOS v17.28 first-use receipt proof status bridge.
 * UI status only. It does not claim success without device/emulator evidence.
 */
data class FirstUseReceiptProofStatusV1728(
    val checkpoint: String = "v17.28",
    val launchProofReady: Boolean = false,
    val diamondWakeConfirmed: Boolean = false,
    val goldOceanCityPreviewConfirmed: Boolean = false,
    val receiptConfirmed: Boolean = false,
    val classification: String = "awaiting_first_use_receipt_evidence",
    val nextAction: String = "Launch app, wake Pure Intelligence, open Gold Ocean City, confirm receipt.",
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object FirstUseReceiptProofBridgeV1728 {
    fun awaiting(): FirstUseReceiptProofStatusV1728 = FirstUseReceiptProofStatusV1728()

    fun fromClassification(classification: String): FirstUseReceiptProofStatusV1728 {
        val pass = classification == "FIRST_USE_RECEIPT_PROOF_READY"
        val next = when (classification) {
            "FIRST_USE_RECEIPT_PROOF_READY" -> "Move to v17.29 pass seal."
            "LAUNCH_CRASH_FIX_REQUIRED" -> "Patch exact launch stack trace only."
            "DIAMOND_WAKE_EVIDENCE_REQUIRED" -> "Confirm or patch center diamond wake bridge."
            "WORLD_PREVIEW_ROUTE_FIX_REQUIRED" -> "Patch Gold Ocean City preview route only."
            "RECEIPT_STORE_FIX_REQUIRED" -> "Patch receipt storage/visibility only."
            else -> "Collect missing first-use evidence."
        }
        return FirstUseReceiptProofStatusV1728(
            launchProofReady = pass || classification.startsWith("DIAMOND_") || classification.startsWith("WORLD_") || classification.startsWith("RECEIPT_"),
            diamondWakeConfirmed = pass || classification.startsWith("WORLD_") || classification.startsWith("RECEIPT_"),
            goldOceanCityPreviewConfirmed = pass || classification.startsWith("RECEIPT_"),
            receiptConfirmed = pass,
            classification = classification,
            nextAction = next
        )
    }
}
