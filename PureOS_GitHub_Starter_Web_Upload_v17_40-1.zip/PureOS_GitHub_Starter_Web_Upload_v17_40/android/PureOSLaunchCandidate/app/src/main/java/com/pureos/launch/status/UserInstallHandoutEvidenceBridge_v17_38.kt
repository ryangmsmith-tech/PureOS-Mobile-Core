package com.pureos.launch.status

/**
 * PureOS v17.38 user install handout / final evidence status bridge.
 * UI-safe status only. It exposes no private foundation internals.
 */
data class UserInstallHandoutEvidenceStatusV1738(
    val checkpoint: String = "v17.38",
    val result: String = "EVIDENCE_MISSING",
    val category: String = "missing_final_evidence",
    val apkProof: Boolean = false,
    val installProof: Boolean = false,
    val launchProof: Boolean = false,
    val diamondWakeProof: Boolean = false,
    val worldPreviewProof: Boolean = false,
    val receiptProof: Boolean = false,
    val finalSealCandidate: Boolean = false,
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object UserInstallHandoutEvidenceBridgeV1738 {
    fun missing(): UserInstallHandoutEvidenceStatusV1738 = UserInstallHandoutEvidenceStatusV1738()

    fun finalSealCandidate(): UserInstallHandoutEvidenceStatusV1738 = UserInstallHandoutEvidenceStatusV1738(
        result = "FIRST_USABLE_FINAL_SEAL_CANDIDATE",
        category = "first_use_final_evidence_passed",
        apkProof = true,
        installProof = true,
        launchProof = true,
        diamondWakeProof = true,
        worldPreviewProof = true,
        receiptProof = true,
        finalSealCandidate = true
    )

    fun exactFixRequired(category: String): UserInstallHandoutEvidenceStatusV1738 =
        UserInstallHandoutEvidenceStatusV1738(
            result = "EXACT_EVIDENCE_FIX_REQUIRED",
            category = category
        )
}
