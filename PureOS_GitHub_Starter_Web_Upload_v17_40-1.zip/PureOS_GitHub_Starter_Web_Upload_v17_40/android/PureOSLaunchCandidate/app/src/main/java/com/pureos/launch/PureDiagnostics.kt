package com.pureos.launch

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PureDiagnostics {
    fun recordLaunch(context: Context, version: String) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val text = "PureOS launch marker: version=$version time=$stamp server_required=false private_foundation_visible=false"
        runCatching { File(context.filesDir, "pureos_launch_marker_v17_5.txt").writeText(text) }
        PureLaunchResultBridge.writePendingResult(context)
    }

    fun statusLine(): String {
        return "Diagnostics active: crash guard installed, logcat runbook ready, first-launch result bridge ready, private foundation sealed, server required false."
    }
}
