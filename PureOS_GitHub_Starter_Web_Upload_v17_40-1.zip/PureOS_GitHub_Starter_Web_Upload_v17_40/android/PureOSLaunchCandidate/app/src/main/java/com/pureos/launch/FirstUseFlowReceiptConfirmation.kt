package com.pureos.launch

/**
 * v17.16 first-use receipt confirmation bridge.
 * This is intentionally local-only and does not expose the private foundation.
 */
data class FirstUseFlowResult(
    val appLaunched: Boolean,
    val diamondTapped: Boolean,
    val pureIntelligenceWoke: Boolean,
    val pureLangCommandRan: Boolean,
    val receiptConfirmed: Boolean,
    val privateFoundationVisible: Boolean = false,
    val serverRequired: Boolean = false
) {
    val passed: Boolean
        get() = appLaunched && diamondTapped && pureIntelligenceWoke && pureLangCommandRan && receiptConfirmed && !privateFoundationVisible && !serverRequired
}

object FirstUseFlowReceiptConfirmation {
    fun confirm(receipts: ReceiptStore): FirstUseFlowResult {
        val summaries = receipts.all().map { it.summary.lowercase() }
        val woke = summaries.any { it.contains("pure intelligence woke") }
        val ranPreview = summaries.any { it.contains("world.preview") || it.contains("gold ocean city") }
        val sealed = summaries.none { it.contains("private foundation visible") }
        val result = FirstUseFlowResult(
            appLaunched = true,
            diamondTapped = woke,
            pureIntelligenceWoke = woke,
            pureLangCommandRan = ranPreview,
            receiptConfirmed = ranPreview,
            privateFoundationVisible = !sealed,
            serverRequired = false
        )
        receipts.save("First-use receipt confirmation result: ${'$'}{if (result.passed) "PASS" else "PENDING_OR_FAIL"} | diamond=${'$'}woke | preview=${'$'}ranPreview | privateFoundationVisible=${'$'}{result.privateFoundationVisible}")
        return result
    }

    fun expectedUserFlow(): List<String> = listOf(
        "Launch Pure OS",
        "Tap center Pure Intelligence diamond",
        "Run task: Open Gold Ocean City preview",
        "Confirm PureLang executes world.preview "gold_ocean_city"",
        "Confirm receipt appears",
        "Confirm private foundation remains sealed"
    )
}
