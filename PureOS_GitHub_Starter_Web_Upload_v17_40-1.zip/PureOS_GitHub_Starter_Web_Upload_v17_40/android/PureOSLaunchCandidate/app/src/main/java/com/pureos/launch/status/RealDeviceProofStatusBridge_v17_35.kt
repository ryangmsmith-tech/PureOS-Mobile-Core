package com.pureos.launch.status

/**
 * PureOS v17.35 real device proof handoff bridge.
 * This is a UI-safe status model only; it does not expose private foundation internals.
 */
data class RealDeviceProofStatusV1735(
    val checkpoint: String = "v17.35",
    val apkProofSeen: Boolean = false,
    val installProofSeen: Boolean = false,
    val launchProofSeen: Boolean = false,
    val firstUseProofSeen: Boolean = false,
    val result: String = "EVIDENCE_MISSING",
    val category: String = "missing_real_device_evidence",
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object RealDeviceProofStatusBridgeV1735 {
    fun missingEvidence(): RealDeviceProofStatusV1735 = RealDeviceProofStatusV1735()

    fun handoffReady(): RealDeviceProofStatusV1735 = RealDeviceProofStatusV1735(
        apkProofSeen = true,
        installProofSeen = true,
        launchProofSeen = true,
        firstUseProofSeen = true,
        result = "FIRST_USABLE_APP_HANDOFF_READY",
        category = "first_use_flow_passed"
    )

    fun exactFixRequired(category: String): RealDeviceProofStatusV1735 = RealDeviceProofStatusV1735(
        result = "EXACT_RUNTIME_FIX_REQUIRED",
        category = category
    )

    fun runtimeFixRetestReady(category: String): RealDeviceProofStatusV1735 = RealDeviceProofStatusV1735(
        result = "RUNTIME_FIX_RETEST_READY",
        category = category
    )
}
