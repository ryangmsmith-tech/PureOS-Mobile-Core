package com.pureos.launchcandidate.system

/**
 * PureOS v17.26 build/APK proof status bridge.
 * UI-facing scaffold only: it does not claim a real APK exists unless evidence is written by scripts.
 */
data class BuildOrApkProofStatus(
    val checkpoint: String = "v17.26",
    val apkExists: Boolean = false,
    val classification: String = "awaiting_real_build_or_apk_proof",
    val nextAction: String = "Run Android Studio/Gradle or provide APK proof.",
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object BuildOrApkProofBridgeV1726 {
    fun awaiting(): BuildOrApkProofStatus = BuildOrApkProofStatus()

    fun fromClassification(classification: String): BuildOrApkProofStatus {
        val next = when (classification) {
            "apk_created" -> "Record checksum, install APK, launch Pure OS, collect first-use proof."
            "kotlin_compile_error" -> "Apply narrow Kotlin compile fix only."
            "compose_configuration_error" -> "Apply narrow Compose configuration fix only."
            "manifest_or_namespace_error" -> "Apply manifest/namespace fix only."
            "resource_error" -> "Apply Android resource fix only."
            "gradle_wrapper_or_plugin_error" -> "Apply Gradle wrapper/plugin fix only."
            "android_sdk_error" -> "Fix Android SDK path or compileSdk only."
            "environment_or_jdk_error" -> "Fix JDK/JAVA_HOME only."
            "dependency_resolution_error" -> "Fix repositories/dependencies only."
            else -> "Run Android Studio/Gradle and save exact output."
        }
        return BuildOrApkProofStatus(
            apkExists = classification == "apk_created",
            classification = classification,
            nextAction = next
        )
    }
}
