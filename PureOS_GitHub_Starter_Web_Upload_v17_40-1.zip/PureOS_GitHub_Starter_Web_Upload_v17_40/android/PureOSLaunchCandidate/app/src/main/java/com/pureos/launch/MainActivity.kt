package com.pureos.launch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PureCrashGuard.install(this)
        PureDiagnostics.recordLaunch(this, "v17.10")
        setContent { PureOSLaunchApp() }
    }
}
