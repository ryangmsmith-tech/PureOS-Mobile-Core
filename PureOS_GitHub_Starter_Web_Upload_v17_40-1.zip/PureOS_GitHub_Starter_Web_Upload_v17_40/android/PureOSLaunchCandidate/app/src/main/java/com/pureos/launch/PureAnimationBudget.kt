package com.pureos.launch

/**
 * PureOS v17.7 animation budget profiles.
 * These are targets, not claimed device results.
 * The runtime should degrade visual cost before it allows UI jank.
 */
object PureAnimationBudget {
    val profiles: Map<String, PureMotionBudgetProfile> = mapOf(
        "mobile_low" to PureMotionBudgetProfile(
            name = "mobile_low",
            targetHz = 60,
            maxTransitionMs = 260,
            maxDiamondWakeMs = 420,
            maxQuickSettingsOpenMs = 300,
            blurAllowed = false,
            prismLayerCount = 1,
            shockwaveSamples = 24
        ),
        "mobile_high" to PureMotionBudgetProfile(
            name = "mobile_high",
            targetHz = 90,
            maxTransitionMs = 240,
            maxDiamondWakeMs = 360,
            maxQuickSettingsOpenMs = 260,
            blurAllowed = true,
            prismLayerCount = 2,
            shockwaveSamples = 48
        ),
        "mobile_ultra" to PureMotionBudgetProfile(
            name = "mobile_ultra",
            targetHz = 120,
            maxTransitionMs = 220,
            maxDiamondWakeMs = 320,
            maxQuickSettingsOpenMs = 240,
            blurAllowed = true,
            prismLayerCount = 3,
            shockwaveSamples = 64
        )
    )

    fun chooseProfile(deviceHint: String): PureMotionBudgetProfile {
        return profiles[deviceHint] ?: profiles.getValue("mobile_low")
    }
}

data class PureMotionBudgetProfile(
    val name: String,
    val targetHz: Int,
    val maxTransitionMs: Int,
    val maxDiamondWakeMs: Int,
    val maxQuickSettingsOpenMs: Int,
    val blurAllowed: Boolean,
    val prismLayerCount: Int,
    val shockwaveSamples: Int
) {
    val frameBudgetMs: Double get() = 1000.0 / targetHz.toDouble()
}
