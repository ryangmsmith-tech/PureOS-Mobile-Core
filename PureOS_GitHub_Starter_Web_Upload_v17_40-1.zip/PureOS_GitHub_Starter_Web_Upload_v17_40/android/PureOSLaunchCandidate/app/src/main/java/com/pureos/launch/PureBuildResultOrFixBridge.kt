package com.pureos.launch

/**
 * PureOS v17.10 build result / narrow fix bridge.
 * This shows whether the debug APK has been produced by a real Gradle run, or
 * what exact area must be fixed next. It never claims APK success without proof.
 */
data class PureBuildResultOrFixStatus(
    val checkpoint: String,
    val environmentDoctor: String,
    val gradleAvailable: Boolean,
    val androidSdkConfigured: Boolean,
    val assembleDebugStatus: String,
    val apkCreated: Boolean,
    val apkPath: String?,
    val nextFixCategory: String?,
    val privateFoundationAccess: Boolean = false,
    val serverRequired: Boolean = false
)

object PureBuildResultOrFixBridge {
    fun pending(): PureBuildResultOrFixStatus = PureBuildResultOrFixStatus(
        checkpoint = "v17.10",
        environmentDoctor = "pending_android_studio_or_cli_gradle_run",
        gradleAvailable = false,
        androidSdkConfigured = false,
        assembleDebugStatus = "not_run_yet",
        apkCreated = false,
        apkPath = null,
        nextFixCategory = "RUN_ENVIRONMENT_DOCTOR_THEN_GRADLE"
    )

    fun displayLine(status: PureBuildResultOrFixStatus = pending()): String {
        return if (status.apkCreated) {
            "Debug APK ready: ${status.apkPath}"
        } else {
            "Debug APK not proven yet. Next fix category: ${status.nextFixCategory ?: "unknown"}. Private foundation sealed."
        }
    }
}
