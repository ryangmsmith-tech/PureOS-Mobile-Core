package com.pureos.launch

/**
 * v17.24 first usable seal bridge.
 * This does not certify a build by itself; it summarizes real evidence state for the System UI.
 */
data class FirstUsableSealStatus(
    val version: String = "v17.24",
    val apkExists: Boolean = false,
    val installPassed: Boolean = false,
    val launchPassed: Boolean = false,
    val diamondWakePassed: Boolean = false,
    val goldOceanCityPreviewPassed: Boolean = false,
    val receiptVisiblePassed: Boolean = false,
    val performanceBlockingJank: Boolean = false,
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
) {
    val sealReady: Boolean
        get() = apkExists && installPassed && launchPassed && diamondWakePassed &&
            goldOceanCityPreviewPassed && receiptVisiblePassed && !performanceBlockingJank &&
            !privateFoundationVisible && !serverRequiredByDefault

    val label: String
        get() = if (sealReady) "First usable Android app seal ready" else "Final narrow fix or evidence required"
}

object FirstUsableSealBridge {
    fun pending(): FirstUsableSealStatus = FirstUsableSealStatus()

    fun classify(status: FirstUsableSealStatus): String {
        if (!status.apkExists) return "apk_missing"
        if (!status.installPassed) return "install_failed"
        if (!status.launchPassed) return "launch_crash"
        if (!status.diamondWakePassed) return "diamond_wake_failed"
        if (!status.goldOceanCityPreviewPassed) return "world_preview_route_failed"
        if (!status.receiptVisiblePassed) return "receipt_store_or_visibility_failed"
        if (status.performanceBlockingJank) return "performance_blocking_jank"
        return if (status.sealReady) "pass_first_usable_flow" else "manual_checks_pending"
    }
}
