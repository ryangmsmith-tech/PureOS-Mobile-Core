package com.pureos.launch

/**
 * PureOS v17.7 Pure Intelligence wake timing policy.
 * Pure Intelligence cannot block ordinary UI animation.
 */
object PureIntelligenceWakeTimingPolicy {
    const val WAKE_FROM_DIAMOND_ONLY_BY_DEFAULT = true
    const val ORDINARY_ROUTE_TAP_WAKES_PI = false
    const val BACKGROUND_TASKS_REQUIRE_APPROVAL = true
    const val PRIVATE_FOUNDATION_VISIBLE = false
    const val SERVER_REQUIRED_BY_DEFAULT = false

    fun wakeStrategy(request: String): String {
        return when (request) {
            "center_diamond" -> "wake_immediately_with_non_blocking_animation"
            "approved_background_task" -> "enqueue_background_task_with_receipt"
            "ordinary_icon_tap" -> "do_not_wake_pure_intelligence"
            else -> "ready_state_review"
        }
    }
}
