package com.pureos.launch

import java.time.Instant

data class ExactBuildFixStatus(
    val checkpoint: String = "v17.14",
    val inputCategory: String = "not_loaded_yet",
    val patchPrepared: Boolean = false,
    val patchAppliedHere: Boolean = false,
    val retryRecommended: Boolean = true,
    val apkCreated: Boolean = false,
    val nextAction: String = "Load the v17.13 parsed build result, prepare exact fix, then retry debug APK build.",
    val updatedAt: String = Instant.now().toString()
)

object ExactBuildFixStatusBridge {
    fun idle(): ExactBuildFixStatus = ExactBuildFixStatus()

    fun fromCategory(category: String): ExactBuildFixStatus {
        val next = when (category) {
            "apk_created" -> "APK exists. Record checksum and move to install/launch candidate."
            "kotlin_compile_error" -> "Patch exact Kotlin compile line/import/type issue."
            "compose_configuration_error" -> "Patch Compose/Kotlin/Gradle compatibility only."
            "manifest_or_namespace_error" -> "Patch namespace, manifest, or exported Activity config only."
            "resource_error" -> "Patch missing/invalid Android resource only."
            "gradle_wrapper_or_plugin_error" -> "Patch Gradle wrapper/plugin version alignment only."
            "android_sdk_error" -> "Fix Android SDK/compile SDK/build tools setup."
            "environment_or_jdk_error" -> "Fix local JDK/Gradle environment first."
            "dependency_resolution_error" -> "Fix dependency repository/version/cache issue only."
            else -> "Collect v17.13 build output before patching."
        }
        return ExactBuildFixStatus(
            inputCategory = category,
            patchPrepared = category != "missing_build_output" && category != "not_loaded_yet",
            apkCreated = category == "apk_created",
            nextAction = next
        )
    }
}
