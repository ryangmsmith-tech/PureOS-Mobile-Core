package com.pureos.launch

/** v17.25 user build handout/evidence merge status bridge. */
data class FirstUsableEvidenceStatus(
    val version: String = "v17.25",
    val apkProofRecorded: Boolean = false,
    val installLaunchRecorded: Boolean = false,
    val diamondWakeConfirmed: Boolean = false,
    val goldOceanCityPreviewConfirmed: Boolean = false,
    val receiptVisibleConfirmed: Boolean = false,
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
) {
    val firstUsableEvidenceMerged: Boolean
        get() = apkProofRecorded && installLaunchRecorded && diamondWakeConfirmed &&
            goldOceanCityPreviewConfirmed && receiptVisibleConfirmed &&
            !privateFoundationVisible && !serverRequiredByDefault

    val statusLabel: String
        get() = if (firstUsableEvidenceMerged) "First usable evidence merged" else "User build evidence pending"
}

object FirstUsableEvidenceBridge {
    fun pending(): FirstUsableEvidenceStatus = FirstUsableEvidenceStatus()
    fun category(status: FirstUsableEvidenceStatus): String {
        if (!status.apkProofRecorded) return "apk_missing_or_unrecorded"
        if (!status.installLaunchRecorded) return "install_launch_unrecorded"
        if (!status.diamondWakeConfirmed) return "diamond_wake_unconfirmed"
        if (!status.goldOceanCityPreviewConfirmed) return "world_preview_unconfirmed"
        if (!status.receiptVisibleConfirmed) return "receipt_visibility_unconfirmed"
        return if (status.firstUsableEvidenceMerged) "pass_first_usable_flow" else "manual_checks_pending"
    }
}
