package com.pureos.launch

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v17.5 on-device first launch result bridge.
 * This file does not claim a real device result by itself. It creates a clean
 * result/evidence path that the Android app and ADB scripts can write into
 * once the debug APK is actually launched on a phone or emulator.
 */
data class FirstLaunchResult(
    val version: String,
    val status: String,
    val device: String,
    val launchOpened: Boolean,
    val diamondWakePassed: Boolean,
    val worldPreviewPassed: Boolean,
    val receiptSaved: Boolean,
    val crashDetected: Boolean,
    val notes: String
)

object PureLaunchResultBridge {
    const val VERSION = "v17.5"

    fun statusSummary(): String {
        return "v17.5 first-launch result bridge ready. Build/install on a real device, then capture launch_result_v17_5.json."
    }

    fun passSummary(): String {
        return "Manual PASS marker accepted only after: app opens, diamond wakes, Gold Ocean City preview opens, receipt saves, no crash markers in logcat."
    }

    fun failSummary(): String {
        return "Manual FAIL marker accepted. Capture logcat and attach debug_output/launch_result_v17_5.json before next crash-fix pass."
    }

    fun benchmarkSummary(): String {
        return "Startup benchmark placeholders ready: cold start, warm start, first tap latency, receipt save latency, frame-jank notes."
    }

    fun writePendingResult(context: Context, note: String = "pending real device test") {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val text = """
            {
              "version": "$VERSION",
              "timestamp": "$stamp",
              "status": "PENDING_REAL_DEVICE_TEST",
              "app_opened": false,
              "diamond_wake_passed": false,
              "world_preview_passed": false,
              "receipt_saved": false,
              "crash_detected": null,
              "server_required_default": false,
              "private_foundation_visible": false,
              "note": "$note"
            }
        """.trimIndent()
        runCatching { File(context.filesDir, "launch_result_v17_5.json").writeText(text) }
    }
}
