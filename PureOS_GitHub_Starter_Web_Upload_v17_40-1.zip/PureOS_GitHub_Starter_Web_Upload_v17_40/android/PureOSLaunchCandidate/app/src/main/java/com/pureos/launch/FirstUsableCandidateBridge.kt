package com.pureos.launch

/**
 * v17.21 first usable Android app candidate status bridge.
 * UI-safe bridge for showing whether Pure OS is installable/usable after real evidence.
 */
data class FirstUsableCandidateStatus(
    val status: String,
    val firstUsableCandidateReady: Boolean,
    val exactFixCategory: String?,
    val nextTarget: String
)

object FirstUsableCandidateBridge {
    fun waiting(): FirstUsableCandidateStatus = FirstUsableCandidateStatus(
        status = "WAITING_FOR_REAL_EVIDENCE",
        firstUsableCandidateReady = false,
        exactFixCategory = null,
        nextTarget = "Run v17.20 retest evidence, then v17.21 gate"
    )

    fun fromGate(decision: String, category: String?): FirstUsableCandidateStatus {
        val ready = decision == "FIRST_USABLE_CANDIDATE_READY"
        return FirstUsableCandidateStatus(
            status = if (ready) "FIRST_USABLE_CANDIDATE_READY" else "EXACT_RETEST_FIX_REQUIRED",
            firstUsableCandidateReady = ready,
            exactFixCategory = if (ready) null else category,
            nextTarget = if (ready) "v17.22 Installable First Usable Android App Proof Core" else "v17.22 First-Use Narrow Fix Retry Core"
        )
    }
}
