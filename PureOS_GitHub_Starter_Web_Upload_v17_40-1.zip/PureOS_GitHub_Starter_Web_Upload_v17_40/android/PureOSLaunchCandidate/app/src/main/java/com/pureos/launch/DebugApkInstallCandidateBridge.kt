package com.pureos.launch

/**
 * v17.15 bridge: reports debug APK / first install candidate status to the System screen.
 * This file is intentionally local-only and does not access the private foundation.
 */
data class DebugApkInstallCandidateState(
    val checkpoint: String = "v17.15",
    val apkExists: Boolean = false,
    val firstInstallCandidate: Boolean = false,
    val apkSha256: String? = null,
    val installAttemptEvidencePresent: Boolean = false,
    val launchAttemptEvidencePresent: Boolean = false,
    val nextStep: String = "Run Android Studio/Gradle build, then check debug APK result."
)

object DebugApkInstallCandidateBridge {
    fun defaultState(): DebugApkInstallCandidateState = DebugApkInstallCandidateState()

    fun summarize(state: DebugApkInstallCandidateState): String {
        return when {
            !state.apkExists -> "No debug APK yet. Run assembleDebug or feed exact build errors into the fix loop."
            state.apkExists && !state.installAttemptEvidencePresent -> "Debug APK exists. Ready for first install candidate attempt."
            state.launchAttemptEvidencePresent -> "Install/launch evidence exists. Move to first-use receipt confirmation."
            else -> state.nextStep
        }
    }
}
