package com.pureos.launch

/**
 * v17.22 bridge: reports whether Pure OS has an installable proof,
 * first-use proof, or a narrow retry requirement.
 * This is UI/status plumbing only; it does not expose private foundation internals.
 */
data class InstallableAppProofState(
    val apkExists: Boolean = false,
    val installPassed: Boolean = false,
    val launchPassed: Boolean = false,
    val diamondWakePassed: Boolean = false,
    val worldPreviewPassed: Boolean = false,
    val receiptVisible: Boolean = false,
    val narrowFixCategory: String? = null
) {
    val installableProofReady: Boolean
        get() = apkExists && installPassed && launchPassed

    val firstUseProofReady: Boolean
        get() = installableProofReady && diamondWakePassed && worldPreviewPassed && receiptVisible

    val decision: String
        get() = when {
            firstUseProofReady -> "FIRST_USE_PROOF_READY"
            installableProofReady -> "INSTALLABLE_PROOF_READY"
            narrowFixCategory != null -> "NARROW_FIX_RETRY_REQUIRED:$narrowFixCategory"
            else -> "AWAITING_REAL_TEST_EVIDENCE"
        }
}

object InstallableAppProofBridge {
    fun summarize(state: InstallableAppProofState): String {
        return "PureOS v17.22 status: ${state.decision}"
    }
}
