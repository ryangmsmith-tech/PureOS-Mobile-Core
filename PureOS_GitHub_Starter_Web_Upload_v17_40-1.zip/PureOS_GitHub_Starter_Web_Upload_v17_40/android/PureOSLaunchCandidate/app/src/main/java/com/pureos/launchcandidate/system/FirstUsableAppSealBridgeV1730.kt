package com.pureos.launchcandidate.system

/**
 * PureOS v17.30 first usable Android app seal / final test fix bridge.
 * UI-facing status only. Real proof must come from Android build/install/launch evidence.
 */
data class FirstUsableAppSealStatusV1730(
    val checkpoint: String = "v17.30",
    val classification: String = "awaiting_real_evidence",
    val apkExists: Boolean = false,
    val firstUsableSealReady: Boolean = false,
    val finalTestFixRequired: Boolean = false,
    val exactFixCategory: String = "none",
    val nextAction: String = "Build APK, install, launch, wake Pure Intelligence, open Gold Ocean City preview, and confirm receipt.",
    val privateFoundationVisible: Boolean = false,
    val serverRequiredByDefault: Boolean = false
)

object FirstUsableAppSealBridgeV1730 {
    fun awaiting(): FirstUsableAppSealStatusV1730 = FirstUsableAppSealStatusV1730()

    fun fromClassification(classification: String, apkExists: Boolean): FirstUsableAppSealStatusV1730 {
        val pass = classification == "FIRST_USABLE_ANDROID_APP_SEAL_READY"
        val category = when (classification) {
            "BUILD_OR_APK_PROOF_REQUIRED" -> "build_or_apk_proof"
            "INSTALL_OR_LAUNCH_PROOF_REQUIRED" -> "install_or_launch_proof"
            "FIRST_USE_PROOF_REQUIRED" -> "first_use_proof"
            "FINAL_TEST_FIX_REQUIRED" -> "final_test_fix"
            "FIRST_USABLE_ANDROID_APP_SEAL_READY" -> "none"
            else -> "unknown"
        }
        val next = when (classification) {
            "FIRST_USABLE_ANDROID_APP_SEAL_READY" -> "Create first usable Android app handout and seal."
            "BUILD_OR_APK_PROOF_REQUIRED" -> "Run Gradle/Android Studio build and record APK proof."
            "INSTALL_OR_LAUNCH_PROOF_REQUIRED" -> "Install/launch APK and collect logcat proof."
            "FIRST_USE_PROOF_REQUIRED" -> "Confirm diamond wake, Gold Ocean City preview, and receipt proof."
            "FINAL_TEST_FIX_REQUIRED" -> "Apply one exact test fix, then retest."
            else -> "Collect real Android evidence."
        }
        return FirstUsableAppSealStatusV1730(
            classification = classification,
            apkExists = apkExists,
            firstUsableSealReady = pass,
            finalTestFixRequired = !pass,
            exactFixCategory = category,
            nextAction = next
        )
    }
}
