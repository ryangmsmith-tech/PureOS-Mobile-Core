package com.pureos.launch

import java.time.Instant

data class BuildResultIntakeState(
    val checkpoint: String = "v17.13",
    val syncAttempted: Boolean = false,
    val buildAttempted: Boolean = false,
    val apkCreated: Boolean = false,
    val exactErrorCategory: String = "not_collected_yet",
    val nextAction: String = "Run Android Studio sync/build and import the output.",
    val updatedAt: String = Instant.now().toString()
)

object BuildResultIntakeBridge {
    fun idle(): BuildResultIntakeState = BuildResultIntakeState()

    fun summarize(category: String, apkCreated: Boolean): BuildResultIntakeState {
        val action = when {
            apkCreated -> "APK exists. Move to install/launch evidence collection."
            category == "kotlin_compile_error" -> "Patch the exact Kotlin compile error in v17.14."
            category == "compose_configuration_error" -> "Patch Compose/Gradle compatibility in v17.14."
            category == "manifest_or_namespace_error" -> "Patch Android manifest/namespace configuration in v17.14."
            category == "resource_error" -> "Patch missing/invalid Android resources in v17.14."
            category == "environment_or_jdk_error" -> "Fix local JDK/Android SDK environment first."
            category == "dependency_resolution_error" -> "Fix dependency/version/network resolution."
            else -> "Collect exact Gradle output before patching."
        }
        return BuildResultIntakeState(
            syncAttempted = true,
            buildAttempted = true,
            apkCreated = apkCreated,
            exactErrorCategory = category,
            nextAction = action
        )
    }
}
