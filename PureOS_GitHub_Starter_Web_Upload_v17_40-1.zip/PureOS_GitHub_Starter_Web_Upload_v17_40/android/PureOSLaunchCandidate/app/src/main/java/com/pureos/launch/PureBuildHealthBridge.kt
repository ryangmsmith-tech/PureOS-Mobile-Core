package com.pureos.launch

/**
 * PureOS v17.8 build health bridge.
 * Shows build/test status inside the System screen once evidence is available.
 */
data class PureBuildHealthReceipt(
    val checkpoint: String,
    val androidStudioSync: String,
    val gradleAssembleDebug: String,
    val apkCreated: Boolean,
    val mainErrorCategory: String?,
    val privateFoundationAccess: Boolean = false,
    val serverRequired: Boolean = false
)

object PureBuildHealthBridge {
    fun notRunYet(): PureBuildHealthReceipt = PureBuildHealthReceipt(
        checkpoint = "v17.8",
        androidStudioSync = "not_run_yet",
        gradleAssembleDebug = "not_run_yet",
        apkCreated = false,
        mainErrorCategory = null
    )

    fun fromManualResult(sync: String, build: String, apkCreated: Boolean, errorCategory: String?): PureBuildHealthReceipt {
        return PureBuildHealthReceipt(
            checkpoint = "v17.8",
            androidStudioSync = sync,
            gradleAssembleDebug = build,
            apkCreated = apkCreated,
            mainErrorCategory = errorCategory
        )
    }
}
