package com.pureos.launch

/**
 * v17.36 static bridge for first usable app handoff seal or runtime fix retest.
 * This bridge stores user-visible status only. It must not expose private foundation internals.
 */
object FirstUsableHandoffSealRuntimeFixRetestBridge {
    const val checkpoint: String = "v17.36"
    const val privateFoundationVisible: Boolean = false
    const val serverRequiredByDefault: Boolean = false

    enum class HandoffDecision {
        FIRST_USABLE_APP_HANDOFF_SEAL_READY,
        RUNTIME_FIX_RETEST_REQUIRED,
        EXACT_RUNTIME_FIX_REQUIRED,
        EVIDENCE_MISSING
    }

    data class HandoffStatus(
        val decision: HandoffDecision,
        val apkProof: Boolean,
        val installProof: Boolean,
        val launchProof: Boolean,
        val diamondWakeProof: Boolean,
        val worldPreviewProof: Boolean,
        val receiptProof: Boolean,
        val message: String
    )

    fun missingEvidence(): HandoffStatus = HandoffStatus(
        decision = HandoffDecision.EVIDENCE_MISSING,
        apkProof = false,
        installProof = false,
        launchProof = false,
        diamondWakeProof = false,
        worldPreviewProof = false,
        receiptProof = false,
        message = "Collect APK, install, launch, Pure Intelligence diamond, world preview, and receipt evidence first."
    )
}
