# Pure OS Android User Build Handout — v17.25

This is the first practical build handout for the Pure OS Android app candidate.

## 1. Open the project

Open Android Studio and choose:

```text
android/PureOSLaunchCandidate/
```

Let Gradle sync.

## 2. Try the debug build

In Android Studio, run:

```text
Build > Make Project
```

Or in terminal from the project folder:

```bash
./gradlew :app:assembleDebug
```

Expected APK path:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 3. Record APK proof

If the APK exists, run:

```bash
bash scripts/record_apk_proof_v17_25.sh
```

This creates:

```text
evidence/v17_25/apk_proof_v17_25.json
```

## 4. Install and launch

Connect your phone with USB debugging enabled, or start an emulator.

Then run:

```bash
bash scripts/install_launch_first_use_v17_25.sh
```

## 5. First-use flow

Inside the app:

```text
Open Pure OS
→ tap the center Pure Intelligence diamond
→ open Chat
→ ask: Open Gold Ocean City preview
→ confirm receipt appears
→ open System and check status
```

## 6. Save result

Fill in:

```text
evidence/v17_25/first_usable_user_result_template.json
```

Then run:

```bash
bash scripts/merge_first_usable_evidence_v17_25.sh
```

## 7. Send the result back

If it fails, send back:

```text
evidence/v17_25/build_output.txt
evidence/v17_25/install_launch_logcat.txt
evidence/v17_25/first_usable_evidence_merge_result.json
```

Then the next patch should fix only the exact failed category.
