# v17.0 Android First Launch Runbook

Project path: `android/PureOSLaunchCandidate/`

## Android Studio

1. Open the `android/PureOSLaunchCandidate` folder.
2. Let Gradle sync.
3. Run the `app` configuration on your phone.
4. Confirm Pure OS opens to the home screen.

## First test

1. Tap the center diamond.
2. Pure Intelligence should wake and switch to Chat.
3. Ask: `Open Gold Ocean City preview`.
4. PureLang should route `world.preview "gold_ocean_city"`.
5. System should save a local receipt.

## Pass condition

- App launches.
- Bottom bar routes work.
- Center diamond wakes Pure Intelligence.
- PureLang command returns a safe result.
- Receipt is visible in System.

## Fail condition

- Crash on launch.
- Navigation broken.
- Receipts unavailable.
- Private foundation visible from UI.
