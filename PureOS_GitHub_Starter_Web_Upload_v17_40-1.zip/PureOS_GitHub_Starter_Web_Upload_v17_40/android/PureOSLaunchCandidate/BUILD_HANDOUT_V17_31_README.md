# Pure OS Android Build Handout — v17.31

Open this folder in Android Studio:

`android/PureOSLaunchCandidate/`

## First action
Try a normal Android Studio sync first.

## Then build
Run:

```bash
./gradlew :app:assembleDebug --stacktrace --info
```

Expected APK path if successful:

`app/build/outputs/apk/debug/app-debug.apk`

## If build succeeds
Run:

```bash
bash scripts/v17_31_record_apk_and_build_output.sh
```

This records:
- APK exists
- APK size
- SHA-256 checksum
- timestamp

## If build fails
Copy the full Gradle output into:

`evidence/v17_31/gradle_output.txt`

Then run:

```bash
python3 tools/ingest_real_apk_or_build_output_v17_31.py
```

## First usable target
Pure OS is considered first usable when:
- APK exists
- APK installs
- App launches
- Home screen appears
- Center Pure Intelligence diamond wakes
- Gold Ocean City preview route works
- Receipt appears or stores
