# PureOS v17.39 — Phone-Only Cloud Build Guide

Ryan, since you do not have a computer right now, the clean path is **cloud build**.

The phone cannot run Android Studio normally, but a cloud builder can run Gradle for you and produce the debug APK as a downloadable artifact.

## Best path from your S25 Ultra

1. Put this PureOS project in a GitHub repository.
2. Keep the included workflow file:

```text
.github/workflows/pureos_android_debug_build.yml
```

3. Open the repository on your phone browser.
4. Go to:

```text
Actions → PureOS Android Debug APK Cloud Build → Run workflow
```

5. Wait for the build to finish.
6. Download the artifact named:

```text
PureOS-debug-apk-and-build-evidence
```

7. If an APK exists inside, install it on your S25 Ultra.
8. If the build fails, download/copy the build evidence and send the error back for the next exact fix patch.

## What this avoids

You do not need Android Studio locally.
You do not need a laptop for the first build attempt.
You only need the project uploaded to a cloud repo that can run the workflow.

## First-use test after install

```text
Open Pure OS
→ tap the center Pure Intelligence diamond
→ Pure Intelligence wakes
→ open Chat
→ type: Open Gold Ocean City preview
→ confirm PureLang receipt appears
```

## Honest status

This checkpoint adds the cloud build path. It does not prove the APK builds until the workflow is run.
