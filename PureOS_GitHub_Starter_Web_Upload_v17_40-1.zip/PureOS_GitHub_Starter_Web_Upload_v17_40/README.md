# PureOS GitHub Starter — v17.40

This package is the phone-friendly GitHub starter for Pure OS v17.40.

It contains the buildable Android launch candidate, the GitHub Actions debug APK workflow, and project guidance for Pure Intelligence, PureLang, and the phone-only cloud build path.

## What to run first

1. Upload this folder to a new GitHub repository.
2. Open the repository.
3. Go to **Actions**.
4. Run **PureOS Android Debug APK Cloud Build**.
5. Download the artifact named **PureOS-debug-apk-and-build-evidence**.
6. If an APK is inside, install it on the phone and run the first-use check.
7. If it fails, copy the exact Actions build log back into ChatGPT for v17.41.

## Main Android project

```text
android/PureOSLaunchCandidate
```

## Main workflow

```text
.github/workflows/pureos_android_debug_build.yml
```

## Project rules

- Intelligence layer name: **Pure Intelligence**
- Command language: **PureLang**
- Approved language: geometry-native, geometry-coded, shape-validated, PureLang, Pure Intelligence
- Ryan approval is required before real deployment claims or risky actions.
- This repository is a prototype/cloud-build path until GitHub Actions produces a real APK artifact and the phone test passes.

## Honest status

This starter package does not prove the APK builds. It gives GitHub Actions the cleanest phone-only path to attempt the build.
